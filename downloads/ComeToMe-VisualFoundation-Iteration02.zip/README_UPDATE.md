# Come to Me — Visual Foundation Iteration 02

Focused, runnable Godot project with only the scene, settings and source views needed for this iteration. It is not a copy of the full GitHub repository.

## Open and run
1. Extract this ZIP to a new folder.
2. Open `project.godot` in the Godot **4.7.2 desktop editor** and let the initial import finish.
3. Press **F5**.
4. Click the game view to capture the mouse. **W/S** move relative to the camera, **A/D** strafe, mouse orbits, wheel adjusts distance, **Esc** releases/captures the pointer.

## Playtest checklist
- Test forward/back, both strafes, all diagonals, changing direction while moving, and releasing input. Judge acceleration, braking and body turn.
- Orbit slowly and quickly, then approach columns, the bench and side walls. Look for clipping, abrupt distance changes, poor player framing, or an obvious camera boundary.
- Check the character at ordinary play distance and while moving in each direction. Does it have spatial presence? Are source-view changes less abrupt?
- Judge scale, composition, shadow, light, revised stone/bronze materials and the single subdued teal seam. Does the space suggest a place and supernatural/technology mystery, or still just primitives?

The project requests Forward+ and D3D12 on Windows, but actual Windows driver/hardware behavior has not been verified here. Iteration 02 has not yet received a display-backed playtest. It adds no combat, creatures, stealth, throwables, audio, HUD, progression, procedural content, or particle effects. The `AnimatedSprite3D` remains a reversible 2.5D hypothesis; the rejected walk sequence is not used.

Optional headless test from a terminal with Godot 4.7.2: `godot --headless --path . --script res://tests/godot_visual_foundation.gd`. A headless PASS is not visual approval. Please share observations or a screenshot/short clip after the display-backed playtest.
